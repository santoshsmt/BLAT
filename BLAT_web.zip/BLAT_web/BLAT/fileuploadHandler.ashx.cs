﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Net;
using Newtonsoft.Json;
namespace BLAT
{
    /// <summary>
    /// Summary description for fileuploadHandler
    /// </summary>
    public class fileuploadHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            JsonSerializer jsonSerializer = new JsonSerializer();


            try
            {
                if (context.Request.Files.Count > 0)
                {
                    HttpFileCollection files = context.Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        HttpPostedFile file = files[i];
                        string fname;
                        if (HttpContext.Current.Request.Browser.Browser.ToUpper() == "IE" || HttpContext.Current.Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                        }
                        fname = Guid.NewGuid().ToString();
                        var uploadPath = HttpContext.Current.Server.MapPath("~/") + "/uploads/";
                        if (!Directory.Exists(uploadPath))
                        {
                            Directory.CreateDirectory(uploadPath);
                        }
                        //if (HttpContext.Current.Server.MapPath(uploadPath))
                        //fname = Path.Combine(context.Server.MapPath("~/uploads/"), fname);
                        file.SaveAs(uploadPath + fname);
                    }
                }
                context.Response.ContentType = "application/json"; ;
                //context.Response.Write("File Uploaded Successfully!");


                Response response = new Response { responseText = "File Uploaded Successfully!" };

                JsonConvert.SerializeObject(response, Formatting.Indented);
            }
            catch (Exception ex)
            {
                context.Response.ContentType = "application/json";
                //context.Response.Write("Error while uploading file!");
                Response response = new Response { responseText = "Error while uploading file!" };

                JsonConvert.SerializeObject(response, Formatting.Indented);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

    public class Response
    {
        public string Message { get; set; }
        public string responseText { get; set; }
    }
}
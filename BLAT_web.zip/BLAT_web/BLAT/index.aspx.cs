﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;

namespace BLAT
{
    public partial class index : System.Web.UI.Page
    {
        public static string OutputFileName = string.Empty;
        static string Source_File_Name = string.Empty;
        public static byte[] FileDataBytes = null;
        public static List<string> FileLines = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
        }

        protected void btnProcess_Click(object sender, EventArgs e)
        {
            FileManager fm = new FileManager();
            string filepath = Server.MapPath("\\Upload");
            HttpFileCollection uploadedFiles = Request.Files;
            try
            {
                string msg = string.Empty;
                //var files = fupFile.PostedFiles; //Directory.GetFiles(Server.MapPath("~/uploads/"));
                

                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];

                        if (userPostedFile.ContentLength > 0)
                        {
                            userPostedFile.SaveAs(filepath + "\\" + Path.GetFileName(userPostedFile.FileName));
                        }

                }
            

                var filepaths = Directory.GetFiles(Server.MapPath("~/Upload/"));
                foreach (string path in filepaths)
                {
                    
                    fm.ReadFile(path);
                    fm.ProcessData(Path.GetFileNameWithoutExtension(path));
                    if (fm.FileDataBytes != null)
                    {
                        //byte[] data = Encoding.UTF8.GetBytes(text);
                        //if (FileManager.CreateLogFile(isMultipleFileSelected))
                        //{
                        fm.CreateLogFile(true);
                        msg = "File Created...";
                        //}
                        //else
                        //{
                        //    msg = "Something wrong please try again.";
                        //}
                    }
                    else
                    {
                        msg = "Unable to read data from file.";
                    }
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                var files = Directory.GetFiles(Server.MapPath("~/Upload/"));
                for (int i = 0; i < files.Count(); i++)
                {
                    Directory.Delete(files[i]);
                }
            }

        }



        public bool CreateLogFile(bool isMultipleFileSelected)
        {
            bool Result = true;
            try
            {
                if (string.IsNullOrEmpty(OutputFileName))
                    OutputFileName = Server.MapPath("~/") + @"\reports\UpdatedLog_" + DateTime.Now.ToString("MM_dd_yyyy_HH_mm_ss_fff") + ".log";

                string path = Path.GetDirectoryName(OutputFileName);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                byte[] header = Encoding.UTF8.GetBytes("FileName|Time|Number|ProcessID|Message_type|MethodName|RequestID|IsBlock|URL|Message\n");
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(OutputFileName))
                {
                    //if (!isMultipleFileSelected)
                    //{
                    //    File.Delete(OutputFileName);
                    //    using (FileStream fs = File.Create(OutputFileName))
                    //    {
                    //        fs.Write(header, 0, header.Length);
                    //        fs.Write(FileDataBytes, 0, FileDataBytes.Length);
                    //    }
                    //}
                    //else
                    //{
                    using (FileStream fs = File.Open(OutputFileName, FileMode.Append))
                    {
                        fs.Write(FileDataBytes, 0, FileDataBytes.Length);
                    }
                    //}
                }
                else
                {
                    using (FileStream fs = File.Create(OutputFileName))
                    {
                        fs.Write(header, 0, header.Length);
                        fs.Write(FileDataBytes, 0, FileDataBytes.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                Result = false;
            }
            finally
            {
                FileDataBytes = null;
            }
            return Result;
        }
    }
}